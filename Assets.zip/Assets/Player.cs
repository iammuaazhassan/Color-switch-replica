using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Player : MonoBehaviour
{
    public float jumpforce = 10f;
    public string currentColor;
    public SpriteRenderer sr;
    public Color colorCyan;
    public Color colorYellow;
    public Color colorPink;
    public Color colorPurple;
    public Rigidbody2D rb;

    public int score = 0;
    public Text scoreText;
    public GameObject gameOverScreen;
    private bool isGameOver = false;

    void Start()
    {
        setRandomColor();
    }

    void Update()
    {
        if (isGameOver)
        {
            if (gameOverScreen.activeSelf)
            {
                if (Input.GetKeyDown(KeyCode.Return))
                {
                    restartGame();
                }
                else if (Input.GetKeyDown(KeyCode.Escape))
                {
                    ExitGame();
                }
            }
            return;
        }

        if (Input.GetButtonDown("Jump") || Input.GetMouseButtonDown(0))
        {
            rb.velocity = Vector2.up * jumpforce;
        }

        if (Input.GetKeyDown(KeyCode.Return))
        {
            restartGame();
        }
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            ExitGame();
        }
    }

    void OnTriggerEnter2D(Collider2D col)
    {
        if (isGameOver)
        {
            return;
        }

        if (col.tag == "ColorChanger")
        {
            setRandomColor();
            col.gameObject.SetActive(false); // Deactivate the ColorChanger
            SpawnerScript spawner = FindObjectOfType<SpawnerScript>();
            spawner.ReturnObjectToPool(col.gameObject); // Return to pool
            addScore();
            return;
        }

        if (col.tag != currentColor)
        {
            Debug.Log("GAME OVER");
            gameOver();
        }
    }

    void setRandomColor()
    {
        int Index = Random.Range(0, 4);
        switch (Index)
        {
            case 0:
                currentColor = "Cyan";
                sr.color = colorCyan;
                break;
            case 1:
                currentColor = "Yellow";
                sr.color = colorYellow;
                break;
            case 2:
                currentColor = "Purple";
                sr.color = colorPurple;
                break;
            case 3:
                currentColor = "Pink";
                sr.color = colorPink;
                break;
        }
        Debug.Log($"New Color: {currentColor}");
    }

    [ContextMenu("INCREASE SCORE")]
    public void addScore()
    {
        score += 1;
        scoreText.text = score.ToString();
    }

    public void restartGame()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    public void gameOver()
    {
        Debug.Log("Game Over!");
        isGameOver = true;
        gameOverScreen.SetActive(true);
    }

    public void ExitGame()
    {
        Debug.Log("Quitting Game...");
        Application.Quit();
    }
}
