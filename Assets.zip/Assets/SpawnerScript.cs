using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnerScript : MonoBehaviour
{
    public GameObject SmallCircle;
    public GameObject ColorChanger;
    public float spawnRate = 2f;
    private float timer = 0f;
    public float heightOffset = 2f;
    private float currentY = 0;
    public int poolSize = 5;

    private Queue<GameObject> colorChangerPool = new Queue<GameObject>();

    void Start()
    {
        currentY = transform.position.y - heightOffset;
        InitializePool();
        spawnObject();
    }

    void Update()
    {
        timer += Time.deltaTime;
        if (timer >= spawnRate)
        {
            spawnObject();
            timer = 0f;
        }
    }

    void spawnObject()
    {
        currentY += heightOffset;
        Instantiate(SmallCircle, new Vector3(transform.position.x, currentY, 0), Quaternion.identity);
        currentY += heightOffset;

        GameObject colorChanger = GetObjectFromPool();
        colorChanger.transform.position = new Vector3(transform.position.x, currentY, 0);
        colorChanger.SetActive(true);
    }

    void InitializePool()
    {
        for (int i = 0; i < poolSize; i++)
        {
            GameObject obj = Instantiate(ColorChanger);
            obj.SetActive(false);
            colorChangerPool.Enqueue(obj);
        }
    }

    GameObject GetObjectFromPool()
    {
        if (colorChangerPool.Count > 0)
        {
            GameObject obj = colorChangerPool.Dequeue();
            return obj;
        }
        else
        {
            GameObject obj = Instantiate(ColorChanger);
            return obj;
        }
    }

    public void ReturnObjectToPool(GameObject obj)
    {
        obj.SetActive(false);
        colorChangerPool.Enqueue(obj);
    }
}
