using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LogicScriptCS : MonoBehaviour
{
    public int score = 0; 
    public Text scoreText;
    
    public void addScore()
    {
        score += 1;
        scoreText.text = score.ToString() ;
    }
    
}
